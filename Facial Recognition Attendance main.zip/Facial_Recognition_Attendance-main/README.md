This is repo that uses python and opencv to create an interface for an attendance management system.
