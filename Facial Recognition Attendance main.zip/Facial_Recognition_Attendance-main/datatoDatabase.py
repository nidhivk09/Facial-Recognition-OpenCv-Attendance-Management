import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
cred = credentials.Certificate("/Users/nidhikulkarni/Desktop/PROJECTS/Attendance_Face_Recognition/serviceAccountKey.json")
firebase_admin.initialize_app(cred,{
    'databaseURL':"https://faceattendance-8318e-default-rtdb.firebaseio.com/"
})


ref=db.reference("Students")

data={
    "151":
    {
        "name":"Nidhi Kulkarni",
        "major":"Computer Science",
        "Starting_year":2023,
        "total_attendance":6,
        "standing":1,
        "year":1 ,
        "Last_attendence_time":"2024-03-14 00:54:34"             
    }
}
for key,value in data.items():
    ref.child(key).set(value)