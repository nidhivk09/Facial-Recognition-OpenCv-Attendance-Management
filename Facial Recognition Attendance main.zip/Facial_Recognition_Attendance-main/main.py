import cv2
import numpy as np
import face_recognition
import os
import pickle
import cvzone
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
from firebase_admin import storage
cred = credentials.Certificate("/Users/nidhikulkarni/Desktop/PROJECTS/Attendance_Face_Recognition/serviceAccountKey.json")
firebase_admin.initialize_app(cred,{
    'databaseURL':"https://faceattendance-8318e-default-rtdb.firebaseio.com/",
    'storageBucket':"faceattendance-8318e.appspot.com"
})



bucket=storage.bucket()
cap=cv2.VideoCapture(1)
cap.set(3,640)
cap.set(4,480)

imgBackground=cv2.imread('/Users/nidhikulkarni/Desktop/PROJECTS/Attendance_Face_Recognition/Resources/background.png')

#importing the mode images into the list

folderModePath='/Users/nidhikulkarni/Desktop/PROJECTS/Attendance_Face_Recognition/Resources/Modes'

modePathList=os.listdir(folderModePath)
imgModeList=[]

for path in modePathList:
    imgModeList.append(cv2.imread(os.path.join(folderModePath,path)))
 #print(len(imgModeList))


#Load the encoding file
print("Loading Encoded file....")
file=open('EncodeFile.p','rb')
encodeListKnownWithIds=pickle.load(file)
file.close()
encodeListKnown,studentids=encodeListKnownWithIds
#print(studentids)
print("Encoded File Loaded")


modeType=0
counter=0
id=-1
imgStudent=[]


while True:
    success, img=cap.read()

    # make the image small as it takes lost of computation power

    imgS=cv2.resize(img,(0,0),None,0.25,0.25)
    imgS=cv2.cvtColor(imgS,cv2.COLOR_BGR2RGB)

    faceCurFrame=face_recognition.face_locations(imgS)
    encodeCurFrame=face_recognition.face_encodings(imgS,faceCurFrame)



    imgBackground[162:162+480,55:55+640] =img
    imgBackground[44:44+633,808:808+414] =imgModeList[modeType]



    for encodeFace,faceLoc in zip(encodeCurFrame,faceCurFrame):
        matches=face_recognition.compare_faces(encodeListKnown,encodeFace)
        faceDis=face_recognition.face_distance(encodeListKnown,encodeFace)
        #print("matches",matches)

        matchIndex=np.argmin(faceDis)

        if matches[matchIndex]:
           # print("Known Face detected")
           # print(studentids[matchIndex])
            y1,x2,y2,x1=faceLoc
            y1,x2,y2,x1=y1*4,x2*4,y2*4,x1*4
            bbox=55+x1,162+y1,x2-x1,y2-y1
            imgBackground= cvzone.cornerRect(imgBackground,bbox,rt=0)#rt=rectangle thickness
            id=studentids[matchIndex]


            if counter==0:
                counter=1
                modeType=1

    if counter!=0:
        if counter==1:
            #get the data
            studentsInfo=db.reference(f'Students/{id}').get()
            print(studentsInfo)

            #get the image from the storage
            blob=bucket.get_blob(f'imageBasic/{id}.jpeg')
            array=np.frombuffer(blob.download_as_string(),np.uint8)
            imgStudent=cv2.imdecode(array,cv2.COLOR_BGRA2BGR)
        
        cv2.putText(imgBackground,str(studentsInfo['total_attendance']),(861,125),cv2.FONT_HERSHEY_COMPLEX,1,(255,255,255),1)
        cv2.putText(imgBackground,str(studentsInfo['major']),(1006,550),cv2.FONT_HERSHEY_COMPLEX,0.5,(255,255,255),1)
        cv2.putText(imgBackground,str(studentsInfo['id']),(1006,493),cv2.FONT_HERSHEY_COMPLEX,0.5,(255,255,255),1)
        cv2.putText(imgBackground,str(studentsInfo['standing']),(910,625),cv2.FONT_HERSHEY_COMPLEX,0.6,(100,100,100),1)
        cv2.putText(imgBackground,str(studentsInfo['year']),(1025,625),cv2.FONT_HERSHEY_COMPLEX,0.6,(100,100,100),1)
        cv2.putText(imgBackground,str(studentsInfo['starting_year']),(1125,625),cv2.FONT_HERSHEY_COMPLEX,0.6,(100,100,100),1)
        (w,h),_=cv2.getTextSize(studentsInfo['name'],cv2.FONT_HERSHEY_COMPLEX,1,1)
        offset=(414-w)//2
        cv2.putText(imgBackground,str(studentsInfo['name']),(808+offset,445),cv2.FONT_HERSHEY_COMPLEX,1,(50,50,50),1)

        imgBackground[175:175+216,90:909+216]=imgStudent


        counter+=1               


    #cv2.imshow("Webcam",img)
    cv2.imshow("Face Attendence",imgBackground)
    cv2.waitKey(1)
